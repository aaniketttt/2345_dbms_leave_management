<footer>
        <div class="footer-area">
        </div>
</footer>